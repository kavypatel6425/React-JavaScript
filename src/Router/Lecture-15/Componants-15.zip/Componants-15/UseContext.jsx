import React, { createContext, useState } from 'react'
import Child_1 from './Child_1';
import Child_3 from './Child_3';

export const text = createContext();
function UseContext() {
    const user = useState("Kavy Patel")
  return (
    <>
    <text.Provider value={`Welcome ${user}`}>
        <Child_3/>
    </text.Provider>
    </>
  )
}

export default UseContext