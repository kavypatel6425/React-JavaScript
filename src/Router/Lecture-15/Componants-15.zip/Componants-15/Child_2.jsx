import React from 'react'

function Child_2() {
  return (
    <div>Child_2</div>
  )
}

export default Child_2