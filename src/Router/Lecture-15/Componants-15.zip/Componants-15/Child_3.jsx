import React, { useContext } from 'react'
import UseContext from './UseContext'

function Child_3() {
   const abc = useContext(user)
  return (
    <>
    <h2>{abc}</h2>
    </>
  )
}

export default Child_3