import React from 'react'
import Index from './Index';
import { useNavigate } from 'react-router-dom';
import Button from 'react-bootstrap/Button';

function Home() {
    const navigat = useNavigate()
    return (
        <>
            <Index />
            <p>Home</p>
            <Button onClick={() => navigat("/contact")}>Go To Contact</Button>
        </>

    )
}

export default Home