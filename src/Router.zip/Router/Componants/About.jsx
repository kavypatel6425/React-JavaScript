import React from 'react'
import Index from './Index';

function About() {
  return (
    <>
      <Index />
      <div>About</div>
    </>

  )
}

export default About