import React from 'react'

function Task_7() {
    const items = [""]

    function add() {
        const input = document.getElementById("inp");
        const value = input.value;

        const li = document.createElement("li");
        li.innerText = value;

        document.getElementById("list").appendChild(li);

        input.value = "";
    }
    return (
        <div>
            <input type="text" id='inp' />
            <button onClick={add}>Add</button>
            <ul id='list'>{items}</ul>
        </div>
    )
}

export default Task_7